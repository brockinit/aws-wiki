const serverless = require("serverless-http");
const express = require("express");
const db = require("./db");
const request = require("request");
const app = express();

app.get("/", function(req, res) {
  res.send("Hello World!");
});

app.get("/test", function(req, res) {
  db.query("SELECT * FROM notes", (err, result) => {
    console.log(result, "data");

    res.json({ data: result.rows });
  });
});

module.exports.handler = serverless(app);
